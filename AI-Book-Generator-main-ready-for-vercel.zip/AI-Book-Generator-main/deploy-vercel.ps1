param(
    [string]$ProjectName = "ai-book-generator",
    [string]$VercelScope = "",          # e.g., your Vercel team slug (optional)
    [string]$VercelToken = $env:VERCEL_TOKEN,  # Recommended to set in your env before running
    [switch]$Prod                        # If set, deploy to production
)

Write-Host "🚀 Starting Vercel static deployment for $ProjectName" -ForegroundColor Cyan

# 1) Prereqs
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { Write-Error "Node.js is required."; exit 1 }
if (-not (Get-Command npm -ErrorAction SilentlyContinue))  { Write-Error "npm is required."; exit 1 }
if (-not (Get-Command vercel -ErrorAction SilentlyContinue)) {
    Write-Host "📦 Installing Vercel CLI globally..." -ForegroundColor Yellow
    npm i -g vercel | Out-Null
}

# 2) Set folder
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root
Write-Host "📁 Working directory: $Root"

# 3) Initialize git (optional but useful for Vercel linking)
if (-not (Test-Path ".git")) {
    git init
    git add .
    git commit -m "Initial commit for Vercel deploy" | Out-Null
}

# 4) Link or create Vercel project
$vcArgs = @("link", "--yes")
if ($VercelScope) { $vcArgs += @("--scope", $VercelScope) }
if ($VercelToken) { $vcArgs += @("--token", $VercelToken) }
$vcArgs += @("--project", $ProjectName)
vercel @vcArgs

# 5) Configure environment variables on Vercel (interactive if no token is provided)
Write-Host "🔑 Setting environment variables on Vercel..."
$envs = @(
    @{ name="OPENAI_API_KEY"; value=$env:OPENAI_API_KEY; target="production" },
    @{ name="OPENAI_API_KEY"; value=$env:OPENAI_API_KEY; target="preview"   },
    @{ name="OPENAI_API_KEY"; value=$env:OPENAI_API_KEY; target="development" },

    @{ name="FIREBASE_API_KEY"; value="AIzaSyAPMz9yGzOhXZAz3g8zBT2BVpqUnwoAg-E"; target="production" },
    @{ name="FIREBASE_AUTH_DOMAIN"; value="tribelifeinspired-3d888.firebaseapp.com"; target="production" },
    @{ name="FIREBASE_PROJECT_ID"; value="tribelifeinspired-3d888"; target="production" },
    @{ name="FIREBASE_STORAGE_BUCKET"; value="tribelifeinspired-3d888.firebasestorage.app"; target="production" },
    @{ name="FIREBASE_MESSAGING_SENDER_ID"; value="617062636859"; target="production" },
    @{ name="FIREBASE_APP_ID"; value="1:617062636859:web:2571d60d27bc34987d6b1e"; target="production" },
    @{ name="FIREBASE_MEASUREMENT_ID"; value="G-3QB8FQDE7R"; target="production" }
)

foreach ($e in $envs) {
    if ($null -ne $e.value -and $e.value -ne "") {
        $args = @("env", "add", $e.name, "--scope", $VercelScope, "--project", $ProjectName, "--$($e.target)")
        if ($VercelToken) { $args += @("--token", $VercelToken) }
        # Pipe the value to vercel env add
        $e.value | vercel @args
    } else {
        Write-Host "Skipping $($e.name) (no value in local env)"
    }
}

# 6) Deploy
$deployArgs = @()
if ($Prod) { $deployArgs += "--prod" }
if ($VercelScope) { $deployArgs += @("--scope", $VercelScope) }
if ($VercelToken) { $deployArgs += @("--token", $VercelToken) }

Write-Host "🚀 Deploying to Vercel..." -ForegroundColor Green
vercel deploy @deployArgs
