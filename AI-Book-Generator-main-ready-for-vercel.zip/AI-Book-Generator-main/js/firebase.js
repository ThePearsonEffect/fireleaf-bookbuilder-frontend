
// Firebase initialization (modular SDK)
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAnalytics, isSupported } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-analytics.js";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAPMz9yGzOhXZAz3g8zBT2BVpqUnwoAg-E",
  authDomain: "tribelifeinspired-3d888.firebaseapp.com",
  projectId: "tribelifeinspired-3d888",
  storageBucket: "tribelifeinspired-3d888.firebasestorage.app",
  messagingSenderId: "617062636859",
  appId: "1:617062636859:web:2571d60d27bc34987d6b1e",
  measurementId: "G-3QB8FQDE7R"
};

// Initialize Firebase (safe-guard for SSR/Edge, though this app is purely client-side)
const app = initializeApp(firebaseConfig);

// Initialize Analytics only if the browser supports it
try {
  if (await isSupported()) {
    const analytics = getAnalytics(app);
    console.log("Firebase Analytics initialized.");
  } else {
    console.log("Firebase Analytics not supported in this environment.");
  }
} catch (e) {
  console.warn("Firebase Analytics init skipped:", e?.message || e);
}
