# Deploying AI Book Generator to Vercel (Static)

These steps assume Windows + PowerShell and that you've unzipped the project.

## 1) Prerequisites
- Node.js + npm installed
- Vercel CLI: `npm i -g vercel`
- (Recommended) Set a Vercel token in your environment: `$env:VERCEL_TOKEN="YOUR_TOKEN"`

## 2) OpenAI Key (local only; app will prompt securely in the browser)
Optionally set your local env var so the script can upload it to Vercel:
```powershell
$env:OPENAI_API_KEY="sk-..."
```

## 3) Run the deployment script
From the project root folder:
```powershell
.\deploy-vercel.ps1 -ProjectName "ai-book-generator" -Prod
```
- If prompted, follow the Vercel CLI steps to link or create a project.
- The script will also attempt to add environment variables (OPENAI_API_KEY and Firebase).

## 4) Firebase Analytics
We added `js/firebase.js` and a `<script type="module" src="js/firebase.js"></script>` tag to `index.html`.
Analytics will initialize in supported browsers only.

## 5) Static Hosting on Vercel
The included `vercel.json` config uses the static build and SPA-style routing to `index.html`.
You can now manage the project in the Vercel dashboard and update env vars there as needed.
